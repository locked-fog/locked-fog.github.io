# AIRIS Style Guide

## Purpose

This document explains how to apply AIRIS to a real webpage correctly.

AIRIS is for dark, industrial, tactical interfaces. It is not a generic SaaS skin, not a neon sci-fi poster, and not a decorative cyberpunk collage.

Use this guide when building:

- dashboards
- control surfaces
- internal tools
- monitoring views
- classified or systems-style interfaces

---

## 1. Start Correctly

Use the shared framework first. Do not rebuild AIRIS by hand inside each page.

```html
<link rel="stylesheet" href="src/styles/framework.css">
```

If you need the interactive utilities currently implemented in JavaScript, load:

```html
<script type="module" src="src/js/components.js"></script>
```

Shared sources:

- `src/styles/tokens/tokens.css`: canonical AIRIS tokens
- `src/styles/framework.css`: imports base + components
- `src/styles/components/*`: shared component contracts
- `src/js/components.js`: current JS utilities for `Slider`, `Navbar`, `Sidebar`, `Toggle`

Rule:

- shared components belong in `src/styles/components/*`
- page-specific showcase or composition rules belong in template/page CSS
- do not patch a one-off page by breaking shared component contracts

---

## 2. Minimal Page Setup

Use a restrained shell first, then add AIRIS motifs deliberately.

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>AIRIS Page</title>
  <link rel="stylesheet" href="src/styles/framework.css">
</head>
<body>
  <main class="app-shell">
    <section class="panel">
      <header class="section-header">
        <span class="micro-label">SYSTEM</span>
        <h1>Operations</h1>
      </header>
      <p>Build from clean structure first, then add emphasis selectively.</p>
    </section>
  </main>
</body>
</html>
```

Build order:

1. tokens
2. layout structure
3. typography
4. component selection
5. classification and accent lines
6. textures and atmospheric detail

Do not reverse that order.

---

## 3. Core Visual Rules

### 3.1 Color

Use AIRIS neutrals as the base.

- `--airis-bg-primary`: page canvas
- `--airis-bg-secondary`: default cards and panels
- `--airis-bg-elevated`: hover or raised surfaces
- `--airis-text-primary`: main readable text
- `--airis-text-secondary`: support text
- `--airis-text-tertiary`: metadata only

Accent usage:

- `--airis-accent`: primary action and key emphasis
- `--airis-accent-cyan`: secondary emphasis
- `--airis-success`, `--airis-warning`, `--airis-danger`, `--airis-info`: semantic status only

Rules:

- keep the canvas dark and stable
- use bright accent sparingly
- do not turn the whole page into a glowing surface
- classification colors are functional meaning, not decoration

### 3.2 Edges and Frames

AIRIS uses hard edges.

- rounded corners should be removed
- default chamfer relationship: top-right and bottom-left
- brackets should sit on the opposite corners
- border and accent lines must follow the chamfer, not stop abruptly at the cut

Use:

- 1px frame lines for normal surfaces
- 2px lines for emphasis
- 3px lines for classification or strong structure

### 3.3 Typography

Readable functional text is mandatory.

Minimums:

- functional body text: 13px minimum
- labels and navigation: 13px minimum
- metadata: 11px minimum
- decorative micro text: 10px maximum, and never used for required reading

Recommended voice:

- headings: `IBM Plex Sans`
- body: `IBM Plex Sans`
- technical labels, serials, metadata: `JetBrains Mono`

Do not:

- style important instructions as microtext
- make buttons, tabs, tags, or form labels tiny for atmosphere
- use low-contrast grey for primary reading surfaces

---

## 4. Layout and Density

AIRIS should feel controlled, not busy.

### Low Detail

Use for most of the page.

- solid surfaces
- simple borders
- very few motifs
- no texture overlays by default

### Medium Detail

Use for emphasis zones.

- one texture family at low opacity
- one stripe band or one classification element
- optional brackets on a few key panels

### High Detail

Use only for hero or identity surfaces.

- multiple motifs
- classification emphasis
- footer systems layer
- careful annotation and atmospheric overlays

Rule:

- keep roughly 80% low detail
- use medium detail selectively
- reserve high detail for a small part of the interface

If everything is loud, AIRIS stops working.

---

## 5. Background Composition

AIRIS backgrounds should support structure, not compete with content.

Optional background devices:

- a single-side vertical strip
- a substantial bottom information bar
- subtle dot, scan, hatch, contour, or grid treatment

Rules:

- use one dominant background treatment plus one minor accent
- keep the main reading zone clean
- textures should remain below content, never overpower text
- if text readability drops, reduce texture opacity first

Good footer content:

- build number
- environment labels
- system identifiers
- copyright
- decorative dots, squares, slashes

---

## 6. Component Application Rules

### Buttons

Use shared `.btn` variants instead of page-local button styling.

Primary:

- use for one main action per area

Secondary:

- use for outlined supporting actions

Ghost:

- use only for low-emphasis actions

Rules:

- line-framed buttons must preserve frame continuity across chamfers
- button text must remain fully readable
- avoid stacking many primary buttons together

### Tabs

Use tabs as operational navigation, not pill-shaped consumer UI.

Recommended:

- page-level navigation: `.tabs--justified.tabs--full-width`
- content-level navigation: default underline tabs
- utility zones: `.tabs--sm`

Rules:

- selected state should be obvious
- underline tabs should align cleanly with content
- use equal-width tabs when they control major page sections

### Panels and Cards

Use panels as restrained containers first.

Rules:

- keep surfaces dark
- use one clear frame system
- add brackets only to key panels
- do not over-decorate every card

### Sidebar

For collapsible sidebars:

- collapsed by default if the pattern is meant to demonstrate collapse
- width change must be visually obvious
- hover or explicit toggle must be real, not implied
- if CSS-only behavior is insufficient, add minimal JS rather than faking the state

### Classification

Classification is a meaning system, not a generic color accent.

Use:

- bars for quick level encoding
- clearance cards for identity/permission surfaces
- strong hierarchy between identifier, bands, and level label

A proper clearance card should contain:

- left: code or identity block
- center: thick horizontal level bands
- right: level number and descriptor

It should read like an institutional credential, not a decorative divider.

---

## 7. Pattern Rules

AIRIS pattern families:

- dotfield
- hatch
- scan
- contour
- grid
- carbon

Usage guidance:

- `dotfield`: subtle depth
- `hatch`: industrial emphasis
- `scan`: screen or sensor atmosphere
- `contour`: mapping and technical depth
- `grid`: tactical or system coordinate feel
- `carbon`: dense high-tech surface

Rules:

- every pattern demo must be visually distinguishable
- animated patterns must actually animate
- opacity must be low enough to preserve text readability
- content overlays need solid or gradient backing if patterns sit underneath text

Do not:

- use several strong textures in the same reading area
- rely on class names alone as proof that a pattern works
- leave pattern demos technically present but visually invisible

---

## 8. Implementation Checklist

Before calling a page “AIRIS-compliant”, verify:

1. The page uses `src/styles/framework.css`, not ad hoc copied rules.
2. Functional text is readable at AIRIS minimum sizes.
3. Rounded corners have been removed.
4. Frames, chamfers, and brackets are structurally consistent.
5. Buttons, tabs, forms, and panels use shared component contracts.
6. Classification colors are used with meaning, not randomly.
7. Textures are visible when intended, subtle when supporting text.
8. Page-level navigation and sidebars behave correctly if they claim to be interactive.
9. Background devices like strips and footer bars stay peripheral and do not pollute the reading surface.
10. The page still works when decorative layers are reduced.

If a design only works because of decorative noise, it is not correctly using AIRIS.

---

## 9. Recommended Workflow

When applying AIRIS to a new page:

1. Start with a plain layout in AIRIS tokens.
2. Choose the correct shared components.
3. Fix readability and spacing first.
4. Add classification or stripe emphasis where it carries information.
5. Add one texture family only where atmosphere helps.
6. Add side strip or footer systems bar only if the page needs a stronger identity layer.
7. Review the result at actual browser scale, not just from source inspection.

AIRIS should feel precise, severe, and systematic. If it starts feeling ornamental, reduce detail.
