# AIRIS

AIRIS is a dark, industrial UI framework for tactical dashboards, control surfaces, and other system-style web interfaces.

This package includes:

- `src/`: framework source files
- `exhibition.html`: live visual reference / component showcase
- `AIRIS-GUIDE.md`: visual language overview
- `AIRIS-style-guide.md`: practical implementation guide

## Quick Start

### 1. Open the reference page

Open `exhibition.html` in a browser to inspect the visual system, components, and usage patterns.

### 2. Use the framework in your own page

Include the shared CSS:

```html
<link rel="stylesheet" href="src/styles/framework.css">
```

If you need the current JavaScript utilities, load:

```html
<script type="module" src="src/js/components.js"></script>
```

## Recommended Reading Order

1. `AIRIS-style-guide.md`
2. `AIRIS-GUIDE.md`
3. `exhibition.html`

## What Each File Is For

### `src/styles/framework.css`

Imports all shared AIRIS tokens, base styles, and components.

### `src/styles/tokens/tokens.css`

Canonical AIRIS design tokens.

### `src/styles/components/*`

Shared component styles. Reuse these instead of rebuilding one-off page styles.

### `src/js/components.js`

Current interactive utilities for:

- `Slider`
- `Navbar`
- `Sidebar`
- `Toggle`

## Minimal Example

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>AIRIS Example</title>
  <link rel="stylesheet" href="src/styles/framework.css">
</head>
<body>
  <main class="app-shell">
    <section class="panel">
      <header class="section-header">
        <span class="micro-label">SYSTEM</span>
        <h1>Operations</h1>
      </header>
      <p>Build from the shared AIRIS structure first, then add emphasis selectively.</p>
      <button class="btn btn--secondary">Open</button>
    </section>
  </main>
</body>
</html>
```

## Important Usage Rules

- Do not use rounded corners.
- Use AIRIS tokens instead of hardcoded colors and spacing.
- Keep most of the interface low-detail; reserve high-detail styling for small emphasis zones.
- Treat classification colors as semantic meaning, not decoration.
- Keep functional text readable; do not style important UI text as microtext.

## Notes

- `exhibition.html` uses Google Fonts. If the target environment has no internet access, self-host the fonts or replace them with local equivalents.
- This package is a source distribution, not a compiled npm package.
