/**
 * =============================================================================
 * UI Components JavaScript Utilities
 * =============================================================================
 * Clean Tech UI Framework - Interactive Components
 * ES6+ Vanilla JavaScript, no dependencies
 * Uses CSS custom properties for state management
 * =============================================================================
 */

/**
 * Slider Component
 * Updates CSS custom properties for fill visualization
 * -----------------------------------------------------------------------------
 */
export class Slider {
  /**
   * Initialize a slider component
   * @param {HTMLElement} element - The slider container element (.slider)
   * @param {Object} options - Configuration options
   * @param {Function} options.onChange - Callback when value changes
   * @param {boolean} options.updateValueDisplay - Whether to update value display text
   */
  constructor(element, options = {}) {
    if (!element) {
      throw new Error('Slider: element is required');
    }

    this.element = element;
    this.options = {
      onChange: null,
      updateValueDisplay: true,
      ...options
    };

    this.input = this.element.querySelector('.slider__input');
    this.valueDisplay = this.element.querySelector('.slider__value');

    if (!this.input) {
      throw new Error('Slider: .slider__input element not found');
    }

    this.min = parseFloat(this.input.min) || 0;
    this.max = parseFloat(this.input.max) || 100;
    this.step = parseFloat(this.input.step) || 1;

    this.init();
  }

  /**
   * Initialize the slider
   * @private
   */
  init() {
    // Set initial CSS custom properties
    this.updateCSSVariables();

    // Bind events
    this.input.addEventListener('input', this.handleInput.bind(this));

    // Handle keyboard navigation enhancements
    this.input.addEventListener('keydown', this.handleKeydown.bind(this));
  }

  /**
   * Handle input event
   * @private
   * @param {Event} event
   */
  handleInput(event) {
    this.updateCSSVariables();

    if (this.options.onChange && typeof this.options.onChange === 'function') {
      this.options.onChange(this.getValue(), this);
    }
  }

  /**
   * Handle keyboard navigation
   * @private
   * @param {KeyboardEvent} event
   */
  handleKeydown(event) {
    const currentValue = this.getValue();
    let newValue = currentValue;

    switch (event.key) {
      case 'ArrowRight':
      case 'ArrowUp':
        newValue = Math.min(this.max, currentValue + this.step);
        event.preventDefault();
        break;
      case 'ArrowLeft':
      case 'ArrowDown':
        newValue = Math.max(this.min, currentValue - this.step);
        event.preventDefault();
        break;
      case 'Home':
        newValue = this.min;
        event.preventDefault();
        break;
      case 'End':
        newValue = this.max;
        event.preventDefault();
        break;
      case 'PageUp':
        newValue = Math.min(this.max, currentValue + this.step * 10);
        event.preventDefault();
        break;
      case 'PageDown':
        newValue = Math.max(this.min, currentValue - this.step * 10);
        event.preventDefault();
        break;
    }

    if (newValue !== currentValue) {
      this.setValue(newValue);
    }
  }

  /**
   * Update CSS custom properties based on current value
   * @private
   */
  updateCSSVariables() {
    const value = this.getValue();
    const percent = ((value - this.min) / (this.max - this.min)) * 100;

    // Set CSS custom properties
    this.element.style.setProperty('--slider-value', value);
    this.element.style.setProperty('--slider-percent', `${percent}%`);

    // Update value display if enabled
    if (this.options.updateValueDisplay && this.valueDisplay) {
      this.valueDisplay.textContent = this.formatValue(value);
    }
  }

  /**
   * Format value for display
   * @private
   * @param {number} value
   * @returns {string}
   */
  formatValue(value) {
    // Format based on step precision
    if (this.step < 1) {
      const decimals = this.step.toString().split('.')[1]?.length || 0;
      return value.toFixed(decimals);
    }
    return Math.round(value).toString();
  }

  /**
   * Get current value
   * @returns {number}
   */
  getValue() {
    return parseFloat(this.input.value) || this.min;
  }

  /**
   * Set slider value
   * @param {number} value
   */
  setValue(value) {
    const clampedValue = Math.max(this.min, Math.min(this.max, value));
    // Round to nearest step
    const steppedValue = Math.round(clampedValue / this.step) * this.step;
    this.input.value = steppedValue;
    this.updateCSSVariables();

    // Trigger change callback
    if (this.options.onChange && typeof this.options.onChange === 'function') {
      this.options.onChange(steppedValue, this);
    }
  }

  /**
   * Destroy the slider instance
   */
  destroy() {
    this.input.removeEventListener('input', this.handleInput);
    this.input.removeEventListener('keydown', this.handleKeydown);
  }

  /**
   * Initialize all sliders in a container
   * @param {HTMLElement} container - Container element (default: document)
   * @param {Object} options - Options to pass to each slider
   * @returns {Slider[]} Array of slider instances
   */
  static initAll(container = document, options = {}) {
    const elements = container.querySelectorAll('.slider');
    return Array.from(elements).map(el => new Slider(el, options));
  }
}

/**
 * Navbar Component
 * Mobile menu toggle functionality
 * -----------------------------------------------------------------------------
 */
export class Navbar {
  /**
   * Initialize navbar component
   * @param {HTMLElement} element - The navbar element (.navbar)
   * @param {Object} options - Configuration options
   * @param {boolean} options.closeOnOutsideClick - Close menu when clicking outside
   * @param {boolean} options.closeOnEscape - Close menu on Escape key
   * @param {Function} options.onToggle - Callback when menu toggles
   */
  constructor(element, options = {}) {
    if (!element) {
      throw new Error('Navbar: element is required');
    }

    this.element = element;
    this.options = {
      closeOnOutsideClick: true,
      closeOnEscape: true,
      onToggle: null,
      ...options
    };

    this.hamburger = this.element.querySelector('.navbar__hamburger');
    this.mobileMenu = this.element.querySelector('.navbar__mobile-menu');
    this.isOpen = false;

    this.init();
  }

  /**
   * Initialize navbar
   * @private
   */
  init() {
    if (this.hamburger) {
      this.hamburger.addEventListener('click', this.toggle.bind(this));
    }

    if (this.options.closeOnEscape) {
      document.addEventListener('keydown', this.handleKeydown.bind(this));
    }

    if (this.options.closeOnOutsideClick) {
      document.addEventListener('click', this.handleOutsideClick.bind(this));
    }

    // Close menu on resize to desktop
    window.addEventListener('resize', this.handleResize.bind(this));
  }

  /**
   * Toggle mobile menu
   */
  toggle() {
    this.isOpen = !this.isOpen;
    this.updateState();

    if (this.options.onToggle && typeof this.options.onToggle === 'function') {
      this.options.onToggle(this.isOpen, this);
    }
  }

  /**
   * Open mobile menu
   */
  open() {
    if (!this.isOpen) {
      this.isOpen = true;
      this.updateState();

      if (this.options.onToggle && typeof this.options.onToggle === 'function') {
        this.options.onToggle(true, this);
      }
    }
  }

  /**
   * Close mobile menu
   */
  close() {
    if (this.isOpen) {
      this.isOpen = false;
      this.updateState();

      if (this.options.onToggle && typeof this.options.onToggle === 'function') {
        this.options.onToggle(false, this);
      }
    }
  }

  /**
   * Update visual state
   * @private
   */
  updateState() {
    if (this.hamburger) {
      this.hamburger.classList.toggle('navbar__hamburger--active', this.isOpen);
      this.hamburger.setAttribute('aria-expanded', this.isOpen.toString());
    }

    if (this.mobileMenu) {
      this.mobileMenu.classList.toggle('navbar__mobile-menu--open', this.isOpen);
      this.mobileMenu.setAttribute('aria-hidden', (!this.isOpen).toString());
    }

    // Prevent body scroll when menu is open
    document.body.classList.toggle('has-navbar-open', this.isOpen);
  }

  /**
   * Handle keyboard events
   * @private
   * @param {KeyboardEvent} event
   */
  handleKeydown(event) {
    if (event.key === 'Escape' && this.isOpen) {
      this.close();
      // Return focus to hamburger
      if (this.hamburger) {
        this.hamburger.focus();
      }
    }
  }

  /**
   * Handle outside clicks
   * @private
   * @param {MouseEvent} event
   */
  handleOutsideClick(event) {
    if (!this.isOpen) return;

    const isClickInside = this.element.contains(event.target);
    if (!isClickInside) {
      this.close();
    }
  }

  /**
   * Handle window resize
   * @private
   */
  handleResize() {
    // Close menu when transitioning to desktop
    const isDesktop = window.matchMedia('(min-width: 768px)').matches;
    if (isDesktop && this.isOpen) {
      this.close();
    }
  }

  /**
   * Check if mobile menu is open
   * @returns {boolean}
   */
  get isMenuOpen() {
    return this.isOpen;
  }

  /**
   * Destroy the navbar instance
   */
  destroy() {
    if (this.hamburger) {
      this.hamburger.removeEventListener('click', this.toggle);
    }
    document.removeEventListener('keydown', this.handleKeydown);
    document.removeEventListener('click', this.handleOutsideClick);
    window.removeEventListener('resize', this.handleResize);
  }

  /**
   * Initialize all navbars in a container
   * @param {HTMLElement} container - Container element (default: document)
   * @param {Object} options - Options to pass to each navbar
   * @returns {Navbar[]} Array of navbar instances
   */
  static initAll(container = document, options = {}) {
    const elements = container.querySelectorAll('.navbar');
    return Array.from(elements).map(el => new Navbar(el, options));
  }
}

/**
 * Sidebar Component
 * Collapsible sidebar with localStorage persistence
 * -----------------------------------------------------------------------------
 */
export class Sidebar {
  /**
   * Initialize sidebar component
   * @param {HTMLElement} element - The sidebar element (.sidebar)
   * @param {Object} options - Configuration options
   * @param {string} options.storageKey - localStorage key for persistence
   * @param {boolean} options.persistState - Whether to persist collapse state
   * @param {boolean} options.defaultCollapsed - Default collapsed state
   * @param {Function} options.onToggle - Callback when sidebar toggles
   */
  constructor(element, options = {}) {
    if (!element) {
      throw new Error('Sidebar: element is required');
    }

    this.element = element;
    this.options = {
      storageKey: 'sidebar-collapsed',
      persistState: true,
      defaultCollapsed: false,
      onToggle: null,
      ...options
    };

    this.toggleBtn = this.element.querySelector('.sidebar__toggle');
    this.isCollapsed = this.getInitialState();

    this.init();
  }

  /**
   * Initialize sidebar
   * @private
   */
  init() {
    // Apply initial state
    this.updateState(false);

    // Bind toggle button
    if (this.toggleBtn) {
      this.toggleBtn.addEventListener('click', this.toggle.bind(this));
      this.toggleBtn.setAttribute('aria-label', 'Toggle sidebar');
      this.toggleBtn.setAttribute('aria-expanded', (!this.isCollapsed).toString());
    }

    // Handle responsive behavior
    this.initResponsive();
  }

  /**
   * Get initial collapsed state from storage or default
   * @private
   * @returns {boolean}
   */
  getInitialState() {
    if (this.options.persistState) {
      const stored = localStorage.getItem(this.options.storageKey);
      if (stored !== null) {
        return stored === 'true';
      }
    }
    return this.options.defaultCollapsed;
  }

  /**
   * Save state to localStorage
   * @private
   */
  saveState() {
    if (this.options.persistState) {
      localStorage.setItem(this.options.storageKey, this.isCollapsed.toString());
    }
  }

  /**
   * Toggle sidebar collapse state
   */
  toggle() {
    this.isCollapsed = !this.isCollapsed;
    this.updateState();
    this.saveState();

    if (this.options.onToggle && typeof this.options.onToggle === 'function') {
      this.options.onToggle(this.isCollapsed, this);
    }
  }

  /**
   * Collapse the sidebar
   */
  collapse() {
    if (!this.isCollapsed) {
      this.isCollapsed = true;
      this.updateState();
      this.saveState();

      if (this.options.onToggle && typeof this.options.onToggle === 'function') {
        this.options.onToggle(true, this);
      }
    }
  }

  /**
   * Expand the sidebar
   */
  expand() {
    if (this.isCollapsed) {
      this.isCollapsed = false;
      this.updateState();
      this.saveState();

      if (this.options.onToggle && typeof this.options.onToggle === 'function') {
        this.options.onToggle(false, this);
    }
    }
  }

  /**
   * Update visual state
   * @private
   * @param {boolean} animate - Whether to animate the transition
   */
  updateState(animate = true) {
    // Toggle collapsed class
    this.element.classList.toggle('is-collapsed', this.isCollapsed);

    // Update aria-expanded attribute
    this.element.setAttribute('aria-expanded', (!this.isCollapsed).toString());

    // Update toggle button
    if (this.toggleBtn) {
      this.toggleBtn.setAttribute('aria-expanded', (!this.isCollapsed).toString());
    }

    // Update main content margin if applicable
    const mainContent = document.querySelector('.has-fixed-sidebar');
    if (mainContent) {
      mainContent.classList.toggle('has-collapsed-sidebar', this.isCollapsed);
    }
  }

  /**
   * Initialize responsive behavior for mobile
   * @private
   */
  initResponsive() {
    // Handle responsive sidebar (slide from side on mobile)
    if (this.element.classList.contains('sidebar--responsive')) {
      // Create backdrop if it doesn't exist
      let backdrop = document.querySelector('.sidebar-backdrop');
      if (!backdrop) {
        backdrop = document.createElement('div');
        backdrop.className = 'sidebar-backdrop';
        backdrop.setAttribute('aria-hidden', 'true');
        document.body.appendChild(backdrop);
      }

      // Close sidebar when clicking backdrop
      backdrop.addEventListener('click', () => {
        this.closeResponsive();
      });

      // Handle escape key
      document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && this.isResponsiveOpen()) {
          this.closeResponsive();
        }
      });

      this.backdrop = backdrop;
    }
  }

  /**
   * Open responsive sidebar (mobile)
   */
  openResponsive() {
    if (this.element.classList.contains('sidebar--responsive')) {
      this.element.classList.add('is-open');
      this.element.setAttribute('aria-expanded', 'true');

      if (this.backdrop) {
        this.backdrop.classList.add('is-visible');
        this.backdrop.setAttribute('aria-hidden', 'false');
      }

      document.body.classList.add('has-sidebar-open');
    }
  }

  /**
   * Close responsive sidebar (mobile)
   */
  closeResponsive() {
    if (this.element.classList.contains('sidebar--responsive')) {
      this.element.classList.remove('is-open');
      this.element.setAttribute('aria-expanded', 'false');

      if (this.backdrop) {
        this.backdrop.classList.remove('is-visible');
        this.backdrop.setAttribute('aria-hidden', 'true');
      }

      document.body.classList.remove('has-sidebar-open');
    }
  }

  /**
   * Check if responsive sidebar is open
   * @returns {boolean}
   */
  isResponsiveOpen() {
    return this.element.classList.contains('is-open');
  }

  /**
   * Check if sidebar is collapsed
   * @returns {boolean}
   */
  get collapsed() {
    return this.isCollapsed;
  }

  /**
   * Destroy the sidebar instance
   */
  destroy() {
    if (this.toggleBtn) {
      this.toggleBtn.removeEventListener('click', this.toggle);
    }

    if (this.backdrop) {
      this.backdrop.remove();
    }
  }

  /**
   * Initialize all sidebars in a container
   * @param {HTMLElement} container - Container element (default: document)
   * @param {Object} options - Options to pass to each sidebar
   * @returns {Sidebar[]} Array of sidebar instances
   */
  static initAll(container = document, options = {}) {
    const elements = container.querySelectorAll('.sidebar');
    return Array.from(elements).map(el => new Sidebar(el, options));
  }
}

/**
 * Toggle Component
 * Synchronizes toggle state with data attributes
 * -----------------------------------------------------------------------------
 */
export class Toggle {
  /**
   * Initialize toggle component
   * @param {HTMLElement} element - The toggle element (.toggle)
   * @param {Object} options - Configuration options
   * @param {Function} options.onChange - Callback when toggle changes
   * @param {boolean} options.syncDataAttribute - Sync checked state to data attribute
   * @param {string} options.dataAttribute - Data attribute name to sync
   */
  constructor(element, options = {}) {
    if (!element) {
      throw new Error('Toggle: element is required');
    }

    this.element = element;
    this.options = {
      onChange: null,
      syncDataAttribute: true,
      dataAttribute: 'data-checked',
      ...options
    };

    this.input = this.element.querySelector('.toggle__input');

    if (!this.input) {
      throw new Error('Toggle: .toggle__input element not found');
    }

    this.init();
  }

  /**
   * Initialize toggle
   * @private
   */
  init() {
    // Set initial data attribute
    this.syncDataAttribute();

    // Bind change event
    this.input.addEventListener('change', this.handleChange.bind(this));

    // Handle click on label (if outside the input)
    this.element.addEventListener('click', this.handleClick.bind(this));
  }

  /**
   * Handle input change event
   * @private
   * @param {Event} event
   */
  handleChange(event) {
    this.syncDataAttribute();

    if (this.options.onChange && typeof this.options.onChange === 'function') {
      this.options.onChange(this.isChecked(), this);
    }
  }

  /**
   * Handle click events (for accessibility)
   * @private
   * @param {MouseEvent} event
   */
  handleClick(event) {
    // If clicking on the toggle but not the input itself, let the label behavior handle it
    // This ensures proper checkbox toggle behavior
    if (event.target === this.element || event.target.closest('.toggle__slider')) {
      // The native label behavior will trigger the change event
    }
  }

  /**
   * Sync checked state to data attribute
   * @private
   */
  syncDataAttribute() {
    if (this.options.syncDataAttribute) {
      const isChecked = this.input.checked;
      this.element.setAttribute(this.options.dataAttribute, isChecked.toString());
      this.element.setAttribute('aria-checked', isChecked.toString());
    }
  }

  /**
   * Check if toggle is checked
   * @returns {boolean}
   */
  isChecked() {
    return this.input.checked;
  }

  /**
   * Set toggle state
   * @param {boolean} checked
   * @param {boolean} triggerCallback - Whether to trigger onChange callback
   */
  setChecked(checked, triggerCallback = true) {
    if (this.input.checked !== checked) {
      this.input.checked = checked;
      this.syncDataAttribute();

      if (triggerCallback && this.options.onChange && typeof this.options.onChange === 'function') {
        this.options.onChange(checked, this);
      }
    }
  }

  /**
   * Toggle the state
   * @param {boolean} triggerCallback - Whether to trigger onChange callback
   */
  toggle(triggerCallback = true) {
    this.setChecked(!this.isChecked(), triggerCallback);
  }

  /**
   * Enable the toggle
   */
  enable() {
    this.input.disabled = false;
    this.element.classList.remove('toggle--disabled');
  }

  /**
   * Disable the toggle
   */
  disable() {
    this.input.disabled = true;
    this.element.classList.add('toggle--disabled');
  }

  /**
   * Check if toggle is disabled
   * @returns {boolean}
   */
  isDisabled() {
    return this.input.disabled;
  }

  /**
   * Destroy the toggle instance
   */
  destroy() {
    this.input.removeEventListener('change', this.handleChange);
    this.element.removeEventListener('click', this.handleClick);
  }

  /**
   * Initialize all toggles in a container
   * @param {HTMLElement} container - Container element (default: document)
   * @param {Object} options - Options to pass to each toggle
   * @returns {Toggle[]} Array of toggle instances
   */
  static initAll(container = document, options = {}) {
    const elements = container.querySelectorAll('.toggle');
    return Array.from(elements).map(el => new Toggle(el, options));
  }
}

/**
 * =============================================================================
 * Utility Functions
 * =============================================================================
 */

/**
 * Initialize all components in a container
 * @param {HTMLElement} container - Container element (default: document)
 * @param {Object} options - Default options for all components
 * @returns {Object} Object containing arrays of initialized components
 */
export function initAllComponents(container = document, options = {}) {
  return {
    sliders: Slider.initAll(container, options.slider),
    navbars: Navbar.initAll(container, options.navbar),
    sidebars: Sidebar.initAll(container, options.sidebar),
    toggles: Toggle.initAll(container, options.toggle)
  };
}

/**
 * Debounce function for performance
 * @param {Function} func - Function to debounce
 * @param {number} wait - Wait time in milliseconds
 * @returns {Function}
 */
export function debounce(func, wait = 100) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

/**
 * Throttle function for performance
 * @param {Function} func - Function to throttle
 * @param {number} limit - Limit time in milliseconds
 * @returns {Function}
 */
export function throttle(func, limit = 100) {
  let inThrottle;
  return function executedFunction(...args) {
    if (!inThrottle) {
      func(...args);
      inThrottle = true;
      setTimeout(() => (inThrottle = false), limit);
    }
  };
}

// Default export with all components
export default {
  Slider,
  Navbar,
  Sidebar,
  Toggle,
  initAllComponents,
  debounce,
  throttle
};
