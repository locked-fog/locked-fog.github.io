# AIRIS Design System — Visual Language Guide

## Overview

AIRIS (Axiom Industries Render Interface System) is a dark, industrial, tactical UI framework designed for building precise, atmospheric interfaces that prioritize readability and systematic structure.

## Design Philosophy

- **Industrial** — Technical, system-like, restrained
- **Tactical** — Clear hierarchy, operational feel
- **Minimal** — Every element must justify its existence
- **Severe** — Dark, high-contrast, confident
- **Atmospheric** — Technical ambiance without decoration overload

## What AIRIS Is

- A design system for command/control interfaces
- A component library for dashboard applications
- A systematic approach to dark UI design
- A complete visual language with codified rules

## What AIRIS Is Not

- A generic startup dashboard kit
- A flashy neon sci-fi concept
- A decorative-only design system
- A random cyberpunk collage
- A generic dark dashboard

---

## A. Color System

### Neutral Hierarchy

| Role | Token | Value | Usage |
|------|-------|-------|-------|
| Background Primary | `--airis-bg-primary` | #0a0a0a | Main page background |
| Background Secondary | `--airis-bg-secondary` | #111111 | Panels, cards |
| Background Elevated | `--airis-bg-elevated` | #1a1a1a | Hover states, modals |
| Background Hover | `--airis-bg-hover` | #222222 | Interactive hover |
| Background Active | `--airis-bg-active` | #2a2a2a | Pressed state |
| Panel | `--airis-panel` | #0f0f0f | Card surfaces |
| Panel Elevated | `--airis-panel-elevated` | #161616 | Elevated cards |

### Text Hierarchy

| Role | Token | Value | Usage |
|------|-------|-------|-------|
| Text Primary | `--airis-text-primary` | #e5e5e5 | Body text, headings |
| Text Secondary | `--airis-text-secondary` | #999999 | Labels, descriptions |
| Text Tertiary | `--airis-text-tertiary` | #666666 | Metadata, timestamps |
| Text Inverse | `--airis-text-inverse` | #0a0a0a | On light backgrounds |

### Accent Families

| Role | Token | Value | Usage |
|------|-------|-------|-------|
| Primary Accent | `--airis-accent` | #ccff00 | Primary actions, highlights |
| Primary Hover | `--airis-accent-hover` | #b3e600 | Hover state |
| Primary Subtle | `--airis-accent-subtle` | rgba(204,255,0,0.1) | Backgrounds |
| Secondary Accent | `--airis-accent-cyan` | #0891b2 | Secondary emphasis |

### Semantic Colors

| Role | Token | Value | Usage |
|------|-------|-------|-------|
| Success | `--airis-success` | #22c55e | Confirmed, operational |
| Warning | `--airis-warning` | #f97316 | Caution, attention |
| Danger | `--airis-danger` | #dc2626 | Error, critical, threat |
| Info | `--airis-info` | #6366f1 | Information, neutral |

### Classification Palette

| Level | Name | Token | Value |
|-------|------|-------|-------|
| 1 | UNCLASSIFIED | `--airis-class-1` | #666666 |
| 2 | INTERNAL | `--airis-class-2` | #999999 |
| 3 | CONFIDENTIAL | `--airis-class-3` | #ccff00 |
| 4 | SECRET | `--airis-class-4` | #f97316 |
| 5 | TOP SECRET | `--airis-class-5` | #dc2626 |

---

## B. Structural Style

### Edge Treatment

AIRIS prefers hard edges over soft corners. Rounded corners should be avoided in favor of straight cuts and chamfered corners:

- `--airis-radius-sm`: 0
- `--airis-radius-md`: 0
- `--airis-radius-lg`: 0
- `--airis-chamfer-size`: 12px default corner cut

### Border Logic

| Weight | Token | Usage |
|--------|-------|-------|
| Thin | 1px | Default borders, dividers |
| Medium | 2px | Focus states, emphasis |
| Thick | 3px | Classification markers |
| Thicker | 4px | Heavy classification |

### Corner Treatment

Brackets and chamfers provide structural emphasis:

- Chamfers: use asymmetric cut corners on framed boxes and controls
- Brackets: 16px default size, 2px thickness
- Default relationship: chamfers on top-right and bottom-left, brackets on the opposite corners
- Structural lines and accent rules should follow the chamfer instead of stopping abruptly at the cut

---

## C. Typography

### Font Families

| Family | Token | Usage |
|--------|-------|-------|
| Display | `--airis-font-display` | Headings, titles |
| Body | `--airis-font-body` | Interface text, labels |
| Mono | `--airis-font-mono` | Code, metadata, timestamps |

### Typography Scale

| Size | Token | Value | Usage |
|------|-------|-------|-------|
| 2xs | `--airis-text-2xs` | 10px | Decorative ONLY |
| xs | `--airis-text-xs` | 11px | Metadata |
| sm | `--airis-text-sm` | 13px | Body text, labels |
| base | `--airis-text-base` | 15px | Large body |
| lg | `--airis-text-lg` | 18px | Headings small |
| xl | `--airis-text-xl` | 24px | Headings |
| 2xl | `--airis-text-2xl` | 32px | Headings large |
| 3xl | `--airis-text-3xl` | 40px | Display |
| 4xl | `--airis-text-4xl` | 56px | Hero |

### Typography Voice

- **Display**: Confident, industrial, bold
- **Body**: Neutral, readable, professional
- **Mono**: Technical, precise, functional

### Functional vs Decorative Text

**FUNCTIONAL TEXT** — Must always be readable:
- Body text: 13px minimum
- Labels: 13px minimum
- Metadata: 11px minimum
- Navigation: 13px minimum

**DECORATIVE TEXT** — Atmospheric only:
- Micro text: 10px, tertiary color
- Used for: serial numbers, coordinates, technical annotations

---

## D. Motif Families

### 1. Classification Bars

**Purpose**: Security clearance encoding

- Thick horizontal bands (3px minimum width)
- Bar count + color = level
- PRIMARY visual element — NOT decoration
- Bars must be THICK, not thin lines
- Bars must be the DOMINANT visual element

### 2. Rule Lines

**Purpose**: Section dividers

- Thin lines (1px default)
- Variants: solid, dotted, segmented
- Use dotted/segmented for decorative variant

### 3. Brackets

**Purpose**: Structural emphasis on key content

- Corner brackets on panels
- Use SPARINGLY — only for hero/key elements
- NOT for every panel

### 4. Stripe Bands

**Purpose**: Editorial accent, content separation

- Horizontal or vertical bands
- Width: 2px (subtle) to 4px (emphasis)
- Color: accent families only
- Use for: emphasis zones, classification headers

### 5. Contour Lines

**Purpose**: Atmospheric background, depth indication

- Repeating linear patterns
- Opacity: 5-15% maximum
- Spacing: 8px minimum
- Use in: backgrounds, subtle overlays

### 6. Control Annotations

**Purpose**: Technical labels, coordinates

- Monospace, uppercase, wide tracking
- Font: Mono, 10px
- Color: Tertiary (subtle)
- Use for: Serial numbers, coordinates, technical IDs

### 7. Node/Serial Tags

**Purpose**: Mark nodes, items, tracked elements

- Small rectangular tags
- Font: Mono, 10px
- Background: Subtle (10% opacity)
- Border: 1px accent

---

## E. Texture Systems

### 1. Dot Field

**Purpose**: Technical atmosphere, measurement reference

- Dot size: 2px
- Spacing: 8px
- Opacity: 15% maximum
- Color: Tertiary

### 2. Hatch Zone

**Purpose**: Indicate special zones, disabled states

- Angle: 45 degrees
- Spacing: 6px
- Opacity: 8% maximum
- Use for: Disabled overlays, special regions

### 3. Scan Texture

**Purpose**: Technical drawing atmosphere

- Line height: 2px
- Gap: 2px
- Opacity: 3% maximum
- Use for: Background atmosphere only

### 4. Contour Overlay

**Purpose**: Depth indication, technical map feel

- Opacity: 5-10%
- Color: Border or tertiary
- Use for: Hero areas, emphasis backgrounds

---

## F. Background Composition

### 1. Single-Side Vertical Strip

**Purpose**: Add directional emphasis without cluttering the full layout

- Use on one side only
- Width: 2px to 4px
- Length: partial, not full-height by default
- Best for: hero zones, section anchors, editorial emphasis
- Pair with: micro labels or classification accents

### 2. Information Footer Bar

**Purpose**: Create a dense system-style lower edge for metadata and atmosphere

- Use a sufficiently tall bottom bar, not a hairline footer
- Fill with small informational or decorative content
- Suitable content: system labels, version/build info, copyright, identifiers, decorative dots/squares/slashes, partner marks
- Typography: mono, uppercase, wide tracking, low contrast unless intentionally highlighted
- Keep the center reading zone clean; treat the footer as a peripheral systems layer

### 3. Background Restraint

- Background motifs should support structure, not compete with content
- Prefer one dominant background treatment plus one minor accent
- If using side strips and footer bars together, keep the central reading surface clean

---

## G. Density Rules

### Low-Detail (Default)

**Use for**: Main layouts, navigation, content areas

- Clean backgrounds (solid)
- Simple borders (1px)
- Minimal motifs (brackets on key elements only)
- No texture overlays
- No hatching or dot fields

### Medium-Detail

**Use for**: Emphasis zones, featured content, classification areas

- Subtle texture overlays (dot field, scan)
- Stripe bands (2px)
- Bracket corners on panels
- Classification bars
- Rule lines (segmented variants)

### High-Detail

**Use for**: Hero sections, title zones, classification displays

- Multiple texture layers
- Bracket combinations
- Full classification bar display
- Contour line patterns
- Micro annotations

**⚠️ Use RESTRAINED** — can overwhelm if overused

---

## H. Combination Rules

### Layer Hierarchy

| Layer | Element |
|-------|---------|
| 0 | Background (solid colors) |
| 1 | Texture overlays (dots, hatching, scan) |
| 2 | Structural elements (borders, panels) |
| 3 | Classification markers (bars, stripes) |
| 4 | Emphasis elements (brackets, glows) |
| 5 | Content (text, controls) |

### Motif Isolation Rules

| Motif | Rule |
|-------|------|
| Classification bars | ISOLATED — don't mix with other motifs in same space |
| Stripe bands | CAN COMBINE with brackets |
| Brackets | CAN COMBINE with stripes, textures |
| Contour lines | CAN COMBINE with textures |
| Control annotations | ISOLATED — don't mix with content |

### Primary vs Secondary

**PRIMARY** (use most often):
- Classification bars (when encoding security)
- Simple borders
- Single bracket corners

**SECONDARY** (use for emphasis):
- Stripe bands
- Texture overlays
- Full bracket sets
- Contour lines

**ACCENT** (use sparingly):
- Glow effects
- Scan animations
- High-detail combinations

### Clutter Prevention

If a motif doesn't serve a purpose, remove it.

**Signs of clutter**:
- Multiple motifs fighting for attention
- Texture overwhelming content
- Too many accent colors
- Brackets on every panel

### Redundancy Prevention

**Don't combine**:
- Two similar dividers (solid + dotted = choose one)
- Classification bar + stripe for same info
- Bracket + border on same edge
- Multiple textures in same space

---

## H. Classification System

AIRIS uses a bar-based classification system inspired by formal access control notations.

### Level Definitions

| Level | Name | Color | Bar Count |
|-------|------|-------|-----------|
| 1 | UNCLASSIFIED | #666666 | 1 |
| 2 | INTERNAL | #999999 | 2 |
| 3 | CONFIDENTIAL | #ccff00 | 3 |
| 4 | SECRET | #f97316 | 4 |
| 5 | TOP SECRET | #dc2626 | 5 |

### Key Principles

- Bars must be THICK (3px minimum)
- Bars must be the DOMINANT visual element
- Level text must be BOLD and readable
- Color must have readable contrast
- This is FUNCTIONAL encoding, NOT decoration

---

## I. Component Guidelines

### Buttons

- **Primary**: Bright accent background (#ccff00), dark text
- **Secondary**: Transparent with accent border
- **Ghost**: No background, subtle hover
- Always ensure text is readable on accent backgrounds

### Badges

- Use for status indicators
- Minimum size: 13px
- Functional status badges are NOT decorative

### Navigation

- Labels: 13px minimum
- Metadata: 11px minimum
- Active state: accent color with underline/bar

### Forms

- Labels: 13px, readable
- Helper text: 11px
- Input text: 13px minimum

---

## J. Accessibility

- All interactive elements must have focus states
- Minimum contrast ratio: 4.5:1 for text
- Functional text must be clearly readable
- Support reduced motion
- Test at actual sizes — don't rely on assumptions

---

## K. Files Reference

### Core Files

| File | Purpose |
|------|---------|
| `src/styles/airis-visual-language.css` | Complete visual language token definitions |
| `src/styles/tokens/colors.css` | Color palette |
| `src/styles/tokens/typography.css` | Typography system |
| `src/styles/tokens/spacing.css` | Spacing system |
| `src/styles/base/global.css` | Base styles, motifs, textures |
| `airis-grammar-board.html` | Visual grammar demonstration |

### Usage

Import the visual language framework:

```css
@import './airis-visual-language.css';
```

Or import legacy-compatible tokens:

```css
@import './framework.css';
```

---

## Dos and Don'ts

### Do

- ✅ Use IBM Plex Sans for headings and body
- ✅ Use JetBrains Mono for code, metadata, timestamps
- ✅ Keep classification bars thick and bold
- ✅ Ensure button text has high contrast
- ✅ Use 13px minimum for functional text
- ✅ Apply brackets sparingly to key panels only
- ✅ Keep macro layouts clean (low-detail)
- ✅ Test readability at actual render size

### Don't

- ❌ Use single font for everything
- ❌ Make classification bars thin like dividers
- ❌ Use decorative text size (10px) for functional content
- ❌ Use weak contrast on bright accent surfaces
- ❌ Over-decorate with brackets
- ❌ Mix decorative motifs without semantic purpose
- ❌ Use classification bars as section dividers
- ❌ Make status badges too small to read
- ❌ Combine multiple textures in one space
- ❌ Use high-detail everywhere — reserve for hero areas
